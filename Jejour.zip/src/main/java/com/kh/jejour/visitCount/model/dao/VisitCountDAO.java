package com.kh.jejour.visitCount.model.dao;

import com.kh.jejour.visitCount.model.vo.VisitCount;

public interface VisitCountDAO {
	public int visitCounter(VisitCount vi);
}
