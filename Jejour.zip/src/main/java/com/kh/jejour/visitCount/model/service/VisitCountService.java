package com.kh.jejour.visitCount.model.service;

import com.kh.jejour.visitCount.model.vo.VisitCount;

public interface VisitCountService {
	public int visitCounter(VisitCount vi);
}
